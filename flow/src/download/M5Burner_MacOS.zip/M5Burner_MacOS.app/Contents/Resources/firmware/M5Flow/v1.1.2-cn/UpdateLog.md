### v1.1.2
* 开机更快
* fix: rgb bug
* fix: 其他bugs
