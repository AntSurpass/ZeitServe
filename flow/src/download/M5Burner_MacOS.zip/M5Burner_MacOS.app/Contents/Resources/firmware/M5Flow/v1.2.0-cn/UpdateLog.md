### v1.2.0
* add: usb upload mode, you can choose it in setup menu
* add: the remote block now is able be used after download,but please save the web control page,because the web control page will be deleted 2 hour later in server
* add: color unit
* fix: some bug
