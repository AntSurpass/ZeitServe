### v1.1.2
* boot more fast
* fix: rgb unit
* fix: some bugs
